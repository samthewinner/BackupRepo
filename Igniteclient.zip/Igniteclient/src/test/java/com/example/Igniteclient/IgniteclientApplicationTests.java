package com.example.Igniteclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IgniteclientApplicationTests {

	@Test
	void contextLoads() {
	}

}
